export const CONTENTARTICLETEXT = `Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloremque, dicta natus? Mollitia laborum voluptatem consequatur nihil ipsam debitis iste. Ea impedit ullam reiciendis ut, suscipit beatae nostrum fugiat sapiente quaerat quam adipisci assumenda, earum nisi ab, illum doloremque unde molestias velit similique est. Architecto iste ut numquam voluptatibus quod et excepturi, possimus quisquam ullam deserunt totam illo optio sunt! Omnis nam quis quo beatae esse. Perspiciatis enim magni, amet facilis beatae unde earum natus numquam, dolorum eum blanditiis corporis quisquam incidunt voluptates similique. Minus quia architecto tempora dignissimos dolores sit eligendi temporibus provident qui omnis, eius quas, repudiandae, doloribus hic.`;

export const HOMEARTICLEINFO = [
    { id: 1, title: `About Us`, paragraphs: 3 },
    { id: 2, title: `And Some More`, paragraphs: 2 }
];