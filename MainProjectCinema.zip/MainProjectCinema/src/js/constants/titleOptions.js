export const titleOptions = [
    { value: ``, display: `Rather not say` },
    { value: `Ms`, display: `Ms` },
    { value: `Miss`, display: `Miss` },
    { value: `Mrs`, display: `Mrs` },
    { value: `Mr`, display: `Mr` },
    { value: `Dr`, display: `Dr` },
];