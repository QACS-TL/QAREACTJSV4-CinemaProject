export const navItems = [
    { "href": "/", "linkText": "Home" },
    { "href": "/schedule", "linkText": "Schedule" },
    { "href": "/signup", "linkText": "Subscribe" },
    { "href": "/", "linkText": "" },
    { "href": "/", "linkText": "" },
    { "href": "/", "linkText": "" }
];