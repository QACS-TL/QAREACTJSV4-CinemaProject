// export const GETALLFILMS = `https://localhost/allFilms`;
// export const GETOPENINGS = `https://localhost/openingTimes`;
// export const GETSINGLEFILM = `https://localhost/singleFilm/`;
// export const POSTSIGNUP = `https://localhost/signup`;

// export const CURRENTFILMSURL = `http://localhost:4000/filmsCurrent`;
// export const FUTUREFILMSURL = `http://localhost:4000/filmsFuture`;
// export const FILMSURL = `http://localhost:4000/films`;
// export const OPENINGSURL = `http://localhost:4000/openings`;
// export const GETSINGLEFILM = `http://localhost:4000/films/`;
// export const POSTSIGNUP = `http://localhost:4000/signups`;

export const CURRENTFILMSURL = `http://localhost:4001/filmsCurrent`;
export const FUTUREFILMSURL = `http://localhost:4001/filmsFuture`;
export const FILMSURL = `http://localhost:4001/films`;
export const OPENINGSURL = `http://localhost:4001/openings`;
export const GETSINGLEFILM = `http://localhost:4001/films/`;
export const POSTSIGNUP = `http://localhost:4001/signups`;