const Footer = () => {
    return (
        <footer>
            <hr />
                <div className="container text-muted" id="footer-txt">
                &copy; Copyright 2024 - QA ltd.
                </div>
        </footer>
    );
}

export default Footer;