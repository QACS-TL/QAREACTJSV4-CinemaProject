import { NavLink } from 'react-router-dom';
import { FILMIMAGES } from '../../../js/constants/images';

const FilmImage = function(source, altn) {
    const src = source;
    const alt = altn;
    return { src, alt };
};

const FilmRow = props => {
    const releaseDateRaw = new Date(props.film.releaseDate);
    const releaseDateDisplay = `${releaseDateRaw.getDate()}-${releaseDateRaw.getMonth() + 1}-${releaseDateRaw.getFullYear()}`;
    //const filmImage = FILMIMAGES[props.film.title] ? FILMIMAGES[props.film.title] : FILMIMAGES['No Image'];
    const filmImage = FilmImage("images/" + props.film.img ? "images/" + props.film.img : FILMIMAGES['No Image']
                       , props.film.img ? props.film.img:'No Image');

   
    console.log(props.film.title)
    console.log(filmImage)
    return (
        <tr>
            <td className="td-center-align">{releaseDateDisplay}</td>
            <td className="td-left-align">
                <NavLink to={`/film/id/${[props.film.id]}`}>
                    {props.film.title}
                </NavLink>
            </td>
            <td>
                {props.film.showingTimes}
            </td>
            <td>
                <img src={filmImage.src} alt={filmImage.alt} width="100" />
            </td>
        </tr>

    );
}

export default FilmRow;