import { NavLink } from 'react-router-dom';

const NavItem = props => {
    return (
        <li className="chevron nav-item">
            {/* OLD react-router-dom V5 logic */}
            {/* <NavLink to={props.destination} className="nav-link" activeClassName="active">{props.linkText}</NavLink> */}
            <NavLink to={props.destination} className="chevron nav-item nav-link active" ><span className="padding">{props.linkText}</span></NavLink>

        </li>

    );
}

export default NavItem;