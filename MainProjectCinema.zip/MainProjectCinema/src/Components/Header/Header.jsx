import NavBar from './NavBar';

const Header = () => {
    return (
        <div className="container sticky-top header" id="qa-navbar">
            <NavBar  />
        </div>
    );
}

export default Header;