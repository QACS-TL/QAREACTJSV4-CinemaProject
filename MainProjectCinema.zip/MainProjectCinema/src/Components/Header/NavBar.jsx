import { navItems } from '../../js/constants/navItems';
import { LOGO } from '../../js/constants/logo';

import NavItem from './NavItem';

const NavBar = () => {
    //console.log(LOGO.src);
    return (
        <nav className="navbar navbar-expand-md navbar-light">
            <a className="navbar-brand" href="https://qa.com"><img src={LOGO.src} alt={LOGO.alt} /></a>
            <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navBarNav" aria-controls="navBarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span className="navbar-toggler-icon"></span>
            </button>
            <div className="chevron  collapse navbar-collapse" id="navBarNav">
                <ul className=" navbar-nav ">
                    {navItems.map((linkItem, index) => <NavItem key={index} destination={linkItem.href} linkText={linkItem.linkText} />)}
                </ul>
            </div>
        </nav>
        
    //     <nav className="navbar navbar-expand-lg navbar-light bg-light">
    //     <div className="container-fluid">
    //       <div >
    //         <ul className="nav">
    //           {navItems.map((item, index) => (
    //             <li className="chevron nav-item" key={index}>
    //               <a className="chevron nav-link" href={item.href}>{item.linkText}</a>
    //             </li>
    //           ))}
    //         </ul>
    //       </div>
    //     </div>
    //   </nav>

    );
}

export default NavBar;